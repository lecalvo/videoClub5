'use strict';

class NavbarController {
  //start-non-standard
  


}

angular.module('videoclubApp')
  .controller('NavbarController', NavbarController);
