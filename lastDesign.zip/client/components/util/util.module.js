'use strict';

angular.module('videoclubApp.util', []);
